//
//  init.h
//  vcx
//
//  Created by GuestUser on 4/30/18.
//  Copyright © 2018 GuestUser. All rights reserved.
//

#ifndef init_h
#define init_h
@interface Console : NSObject

+ ( void )log:(NSString *)message;

@end

#endif /* init_h */
